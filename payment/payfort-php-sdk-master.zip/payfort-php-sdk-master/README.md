payfort-php-SDK
======================

Payfort payment gateway SDK

Install
=======

1. Go to server document root

2. checkout the project to document root

Notes
=====

- trace.log folder must have read/write permission
- All requests and responses are logged to trace.log file
- you can use theme in the SDK or customize it , you can also create your own design by using the SDK functions directly 
- Integration supperted:
	* Credit card (redirection)
	* Credit card (Merchant page)
	* Credit card (Merchant page 2.0)
	* Installemnts (redirection) 
	* SADAD 
	* NAPS 

	