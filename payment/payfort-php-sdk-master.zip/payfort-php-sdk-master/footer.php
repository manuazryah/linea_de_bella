        </div>
        <footer>
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Mollitia voluptatibus obcaecati eveniet id reiciendis eligendi
        </footer>
    </body>
</html>
